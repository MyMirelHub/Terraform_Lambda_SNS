from __future__ import print_function
def handler(event, context):
    print('Hello World')
    return 'Hello World!'  